/**
 * 今日提示：客户端半（浏览器模块装载器的注册形制，与出厂 ui-* 包、我的记忆同款；
 * 示例扩展：官仓库安装链路的试点样品）。
 *
 * - 远端：自挂本包的描述符（`ctx.remote.hint.*`）。参数 codec 用占位 strict 形状：
 *   客户端面不解码参数（校验在宿主面按 schema 进行），与服务端 `src/wire.ts` 同步。
 * - 页面：侧栏「提示」入口＋主面板一屏一条；首页卡片同卡（无跳转链接）。
 * - 颜色与版式取自色卡（@edu-x/theme-color）与字体卡（@edu-x/theme-type）。
 * - 文案为简体中文静态文案。
 */
window.__ModuleLoader__.load({
  id: '@edu-x/extension-hint',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports

    const react = require('react')
    const h = react.createElement
    const { color } = require('@edu-x/theme-color')
    const { type } = require('@edu-x/theme-type')

    const PKG = '@edu-x/extension-hint'
    const SLOT_KEY = 'hint'
    const CLASS_PAGE = 'edu-hint-page'

    const TEXT = {
      page: '今日提示',
      sidebar: '提示',
      empty: '今天没有提示。',
      failed: '提示没有取到，稍后再看。',
    }

    //#region 远端描述符（与服务端 src/wire.ts 保持同步）
    const direct = { kind: 'direct' }
    const placeholderCodec = (symbol) => ({
      mode: 'strict',
      typeSymbol: PKG + '#' + symbol,
      create: () => {
        throw new Error('client api: 参数 schema 只在宿主面提供')
      },
    })
    const invocation = (name, parameters) => ({
      id: PKG + '#hint/' + name,
      service: 'eduHint',
      namespace: 'hint',
      method: name,
      invocation: direct,
      parameters,
      result: { mode: 'src-json' },
    })
    const DESCRIPTORS = [invocation('today', [])]
    //#endregion

    const STYLES = {
      page: {
        maxWidth: 640,
        margin: '0 auto',
        padding: '40px 24px 64px',
        display: 'flex',
        flexDirection: 'column',
        gap: 20,
        fontFamily: type.family.ui,
        fontSize: type.size.body,
        color: color.text,
      },
      title: {
        fontSize: type.size.title,
        fontFamily: type.family.heading,
        color: color.text,
        margin: 0,
      },
      card: {
        borderLeft: `3px solid ${color.brand}`,
        padding: '12px 16px',
        background: color.surfaceSubtle,
      },
      date: { fontSize: type.size.small, color: color.textMuted, margin: 0 },
      line: { margin: '6px 0 0', lineHeight: 1.7 },
      muted: { color: color.textMuted },
      sidebarIcon: { width: 18, height: 18, color: color.brand },
    }

    /** 今日提示主面板：挂载完成后取数；失败只显示说明，不挡页面。 */
    function makeHintPage(ctx, mounted) {
      const client = () => ctx.get('remote.hint')

      function HintPage() {
        const [state, setState] = react.useState({ status: 'loading', value: null })
        react.useEffect(() => {
          let alive = true
          void (async () => {
            await mounted
            try {
              const result = await client().today()
              if (alive) setState({ status: 'ready', value: result.ok ? result.value : null })
            } catch {
              if (alive) setState({ status: 'failed', value: null })
            }
          })()
          return () => {
            alive = false
          }
        }, [])

        return h(
          'section',
          { className: CLASS_PAGE, style: STYLES.page },
          h('h1', { style: STYLES.title }, TEXT.page),
          state.status === 'loading'
            ? h('p', { style: STYLES.muted }, '…')
            : state.value === null
              ? h(
                  'p',
                  { style: STYLES.muted },
                  state.status === 'failed' ? TEXT.failed : TEXT.empty,
                )
              : h(
                  'blockquote',
                  { style: STYLES.card },
                  h('p', { style: STYLES.date }, state.value.date),
                  h('p', { style: STYLES.line }, state.value.line),
                ),
        )
      }
      return HintPage
    }

    /** 首页卡片：同一屏的小卡（无跳转；主画面已经装了这一页）。 */
    function makeHintCard(ctx, mounted) {
      const client = () => ctx.get('remote.hint')

      function HintCard() {
        const [state, setState] = react.useState({ status: 'loading', value: null })
        react.useEffect(() => {
          let alive = true
          void (async () => {
            await mounted
            try {
              const result = await client().today()
              if (alive) setState({ status: 'ready', value: result.ok ? result.value : null })
            } catch {
              if (alive) setState({ status: 'failed', value: null })
            }
          })()
          return () => {
            alive = false
          }
        }, [])

        return h(
          'section',
          { className: CLASS_PAGE, style: STYLES.page },
          h('h2', null, TEXT.page),
          state.status === 'loading'
            ? h('p', { style: STYLES.muted }, '…')
            : state.value === null
              ? h('p', { style: STYLES.muted }, TEXT.empty)
              : h('p', { style: STYLES.line }, state.value.line),
        )
      }
      return HintCard
    }

    /** 侧栏图标：一枚铃铛样式的极简形状。 */
    function HintIcon() {
      return h(
        'svg',
        {
          viewBox: '0 0 24 24',
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.6,
          strokeLinecap: 'round',
          style: STYLES.sidebarIcon,
          'aria-hidden': true,
        },
        h('path', { d: 'M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z' }),
        h('path', { d: 'M10 18a2 2 0 0 0 4 0' }),
      )
    }

    const CSS = [
      `.${CLASS_PAGE} { box-sizing: border-box; }`,
      `.${CLASS_PAGE} h1:focus-visible { outline: 2px solid ${color.brand}; outline-offset: 2px; }`,
    ].join('\n')

    /** 必需的服务：槽位与远端投影（$mount 用的根投影）。 */
    const inject = ['slots', 'remote']

    function apply(ctx) {
      ctx.effect(() => {
        const tag = document.createElement('style')
        tag.setAttribute('data-edu-hint', '')
        tag.textContent = CSS
        document.head.appendChild(tag)
        return () => tag.remove()
      }, 'edu-hint: 样式')
      const mounted = (async () => {
        const disposer = await ctx.remote.$mount({ package: PKG, descriptors: DESCRIPTORS })
        ctx.effect(() => disposer)
      })()
      ctx.slots.inject('main', () =>
        ctx.slots.register({ name: 'main', key: SLOT_KEY }, makeHintPage(ctx, mounted)),
      )
      ctx.slots.inject('home.card', () =>
        ctx.slots.register(
          { name: 'home.card', id: SLOT_KEY, order: 40 },
          makeHintCard(ctx, mounted),
        ),
      )
      ctx.slots.inject('sidebar.panellist', () =>
        ctx.slots.register(
          { name: 'sidebar.panellist', id: SLOT_KEY, order: 30, label: () => TEXT.sidebar },
          HintIcon,
        ),
      )
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
