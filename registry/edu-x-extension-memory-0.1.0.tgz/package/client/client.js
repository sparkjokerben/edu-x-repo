/**
 * 我的记忆：客户端半（浏览器模块装载器的注册形制，与出厂 ui-* 包同款）。
 *
 * - 远端：自挂本包的描述符（`ctx.remote.memory.*`）。参数 codec 用占位 strict
 *   形状：客户端面不解码参数（校验在服务端按 schema 进行），故 `create` 惰性
 *   为空实现；与服务端 `src/wire.ts` 的描述符须保持两端同步。
 * - 页面：「我的记忆」主面板（`main` 键控槽，键 `memory`）＋侧栏导航。
 * - 颜色与版式取自色卡（@edu-x/theme-color）与字体卡（@edu-x/theme-type），本文件不写死色值。
 * - 会话里的写入确认由出厂审批卡承担；本页面是老师直接落笔（无需确认卡）。
 * - 文案 M1 为简体中文静态文案（界面本地化随后续语言包阶段）。
 */
window.__ModuleLoader__.load({
  id: '@edu-x/extension-memory',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports

    const react = require('react')
    const h = react.createElement
    const { color } = require('@edu-x/theme-color')
    const { type } = require('@edu-x/theme-type')

    const PKG = '@edu-x/extension-memory'
    const SLOT_KEY = 'memory'
    const CLASS_PAGE = 'edu-memory-page'

    //#region 远端描述符（与服务端 src/wire.ts 保持同步）
    const direct = { kind: 'direct' }
    const placeholderCodec = (symbol) => ({
      mode: 'strict',
      typeSymbol: PKG + '#' + symbol,
      create: () => {
        throw new Error('client api: 参数 schema 只在宿主面提供')
      },
    })
    const invocation = (name, parameters) => ({
      id: PKG + '#memory/' + name,
      service: 'eduMemory',
      namespace: 'memory',
      method: name,
      invocation: direct,
      parameters,
      result: { mode: 'src-json' },
    })
    const DESCRIPTORS = [
      invocation('page', []),
      invocation('write', [
        {
          name: 'request',
          wire: 'request',
          source: 'json',
          codec: placeholderCodec('MemoryWriteRequest'),
        },
      ]),
      invocation('removeEntry', [
        {
          name: 'request',
          wire: 'request',
          source: 'json',
          codec: placeholderCodec('MemoryRemoveEntryRequest'),
        },
      ]),
      invocation('removeBook', [
        {
          name: 'request',
          wire: 'request',
          source: 'json',
          codec: placeholderCodec('MemoryRemoveBookRequest'),
        },
      ]),
    ]
    //#endregion

    //#region 侧栏图标：两册叠放的书页
    function MemoryIcon() {
      return h(
        'svg',
        {
          width: 18,
          height: 18,
          viewBox: '0 0 24 24',
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.6,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-label': '我的记忆',
          role: 'img',
        },
        h('path', { d: 'M5 4h9.5a2.5 2.5 0 0 1 2.5 2.5V20H7.5A2.5 2.5 0 0 1 5 17.5Z' }),
        h('path', { d: 'M17 20h1.5A2.5 2.5 0 0 0 21 17.5V7l-4-3' }),
        h('path', { d: 'M9 9h5M9 13h5' }),
      )
    }
    //#endregion

    const TEXT = {
      page: '我的记忆',
      lede: '老师记下的事，秘书长会参考。',
      pageShort: '记忆',
      write: '记一条',
      writePlaceholder: '要记住的事，一句话。比如：家长会定在下周四。',
      saved: (book) => `已记入「${book}」册。`,
      savedFallback: (book) => `已记下，暂放入「${book}」册，稍后可以在这里整理。`,
      empty: '还没有记下任何事。在对话里请秘书长记，或直接在上面写一条。',
      deleteEntry: '删除',
      deleteBook: '删除整册',
      confirmDelete: '再点一次确认删除',
      loadFailed: '记忆没有读取成功，请稍后重试。',
      retry: '重试',
      writing: '正在记…',
      opening: '正在打开记忆…',
      emptyText: '请先写下要记的内容。',
      modified: '内容被改动过',

      cardEmpty: '还没有记下任何事。',
      cardMore: '查看全部',
    }

    const messageOf = (result) => {
      const error = result && result.error ? result.error : null
      if (error !== null && typeof error.code === 'string' && error.code.startsWith('gateway/'))
        return TEXT.loadFailed
      return error !== null && typeof error.message === 'string' && error.message !== ''
        ? error.message
        : TEXT.loadFailed
    }

    const entryCount = (group) => `${String(group.items.length)} 条`

    //#region 记忆页
    /** 「我的记忆」主面板。数据与写入都走 `ctx.get('remote.memory')`；老师就是落笔的人。 */
    /** 组件工厂：闭包持 ctx 与挂载序（挂载完成前页面显示「正在打开记忆…」）。 */
    function makeMemoryPage(ctx, mounted) {
      // 命名空间服务由 $mount 在根上下文提供；属性投影按注入清单取用，
      // 这里用通用 get（跨上下文可达、不需要把键写进模块注入清单）。
      const client = () => ctx.get('remote.memory')

      function MemoryPage() {
        const [groups, setGroups] = react.useState(null)
        const [draft, setDraft] = react.useState('')
        const [notice, setNotice] = react.useState('')
        const [writing, setWriting] = react.useState(false)
        const [armed, setArmed] = react.useState('')

        const reload = react.useCallback(() => {
          void (async () => {
            await mounted
            const result = await client().page()
            // 成功只刷数据，不清提示（刚写入的「已记入…」要留着给老师看）；
            // 失败把原因摆出来
            if (result.ok) setGroups(result.value)
            else setNotice(messageOf(result))
          })()
        }, [])

        react.useEffect(() => {
          reload()
        }, [reload])

        if (groups === null) {
          // 首帧与挂载中的占位；取数失败时给出重试入口，不让页面死在「打开中」
          return h(
            'div',
            { className: CLASS_PAGE, style: STYLES.page },
            notice === '' ? null : h('p', { style: STYLES.notice, role: 'status' }, notice),
            notice === ''
              ? h('p', { style: STYLES.muted }, TEXT.opening)
              : h(
                  'div',
                  { style: STYLES.retryBox },
                  h('p', { style: STYLES.muted }, TEXT.loadFailed),
                  h(
                    'button',
                    {
                      style: STYLES.ghostButton,
                      onClick: () => {
                        setNotice('')
                        reload()
                      },
                    },
                    TEXT.retry,
                  ),
                ),
          )
        }

        const submit = async () => {
          const text = draft.trim()
          if (text === '') {
            setNotice(TEXT.emptyText)
            return
          }
          setWriting(true)
          setNotice('')
          try {
            const result = await client().write({ text })
            if (result.ok === false) setNotice(messageOf(result))
            else {
              setDraft('')
              setNotice(
                result.value.guessed === true
                  ? TEXT.savedFallback(result.value.book)
                  : TEXT.saved(result.value.book),
              )
            }
          } catch (error) {
            setNotice(error instanceof Error ? error.message : TEXT.loadFailed)
          }
          setWriting(false)
          reload()
        }

        const removeEntry = async (id) => {
          const key = `e${String(id)}`
          if (armed !== key) {
            setArmed(key)
            return
          }
          setArmed('')
          setNotice('')
          const result = await client().removeEntry({ entryId: id })
          if (result.ok === false) setNotice(messageOf(result))
          reload()
        }

        const removeBook = async (name) => {
          const key = `b${name}`
          if (armed !== key) {
            setArmed(key)
            return
          }
          setArmed('')
          setNotice('')
          const result = await client().removeBook({ name })
          if (result.ok === false) setNotice(messageOf(result))
          else setNotice('')
          reload()
        }

        const body =
          groups.length === 0
            ? h('p', { style: STYLES.muted }, TEXT.empty)
            : h(
                'div',
                { style: STYLES.groups },
                groups.map((group) =>
                  h(
                    'section',
                    { key: group.name, style: STYLES.group },
                    h('header', { style: STYLES.groupHead }, [
                      h('h2', { style: STYLES.groupName }, `${group.name}`),
                      h('span', { style: STYLES.count }, entryCount(group)),
                      h(
                        'button',
                        {
                          style:
                            armed === `b${group.name}` ? STYLES.dangerButton : STYLES.ghostButton,
                          onClick: () => removeBook(group.name),
                        },
                        armed === `b${group.name}` ? TEXT.confirmDelete : TEXT.deleteBook,
                      ),
                    ]),
                    h(
                      'ul',
                      { style: STYLES.list },
                      group.items.map((item) =>
                        h(
                          'li',
                          { key: String(item.id), style: STYLES.item },
                          h(
                            'p',
                            {
                              style:
                                item.intact === false ? STYLES.itemTextModified : STYLES.itemText,
                            },
                            item.text,
                          ),
                          h(
                            'footer',
                            { style: STYLES.itemMeta },
                            h('span', { style: STYLES.meta }, metaLine(item)),
                            h(
                              'button',
                              {
                                style:
                                  armed === `e${String(item.id)}`
                                    ? STYLES.dangerButton
                                    : STYLES.ghostButton,
                                onClick: () => removeEntry(item.id),
                              },
                              armed === `e${String(item.id)}`
                                ? TEXT.confirmDelete
                                : TEXT.deleteEntry,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )

        return h(
          'div',
          { className: CLASS_PAGE, style: STYLES.page },
          h(
            'header',
            { style: STYLES.head },
            h('h1', { style: STYLES.title }, TEXT.page),
            h('p', { style: STYLES.lede }, TEXT.lede),
          ),
          h(
            'div',
            { className: 'edu-memory-composer', style: STYLES.composer },
            h('textarea', {
              style: STYLES.input,
              value: draft,
              placeholder: TEXT.writePlaceholder,
              rows: 2,
              onChange: (event) => setDraft(event.target.value),
              'aria-label': TEXT.write,
            }),
            h(
              'div',
              { style: STYLES.composerBar },
              h(
                'button',
                { style: STYLES.primaryButton, disabled: writing, onClick: submit },
                writing === true ? TEXT.writing : TEXT.write,
              ),
            ),
          ),
          notice === '' ? null : h('p', { style: STYLES.notice, role: 'status' }, notice),
          body,
        )
      }

      function metaLine(item) {
        const parts = [`${item.at.slice(0, 10)} 记入`]
        if (item.intact === false) parts.push(TEXT.modified)
        return parts.join('，')
      }
      return MemoryPage
    }
    //#endregion

    //#region 首页卡片：最近记下的几条（插件经 home.card 槽注册，见 docs）
    /** 按时间倒序取最近三条。 */
    function recentOf(groups) {
      return groups
        .flatMap((group) => group.items)
        .sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : 0))
        .slice(0, 3)
    }

    /** 首页卡片组件工厂：挂载完成后取数；取数失败也只显示空态，不挡首页。 */
    function makeMemoryCard(ctx, mounted) {
      const client = () => ctx.get('remote.memory')

      function MemoryCard({ openPanel }) {
        const [recent, setRecent] = react.useState(null)

        react.useEffect(() => {
          let alive = true
          void (async () => {
            await mounted
            const result = await client().page()
            if (alive) setRecent(result.ok ? recentOf(result.value) : [])
          })()
          return () => {
            alive = false
          }
        }, [])

        return h(
          'section',
          { style: STYLES.card },
          h('h2', { style: STYLES.cardTitle }, TEXT.page),
          recent === null
            ? h('p', { style: STYLES.muted }, TEXT.opening)
            : recent.length === 0
              ? h('p', { style: STYLES.muted }, TEXT.cardEmpty)
              : h(
                  'ul',
                  { style: STYLES.recentList },
                  recent.map((item) =>
                    h('li', { key: String(item.id), style: STYLES.recentItem }, item.text),
                  ),
                ),
          h(
            'button',
            {
              type: 'button',
              style: STYLES.cardLink,
              onClick: () => openPanel(SLOT_KEY),
            },
            TEXT.cardMore,
          ),
        )
      }
      return MemoryCard
    }
    //#endregion

    /**
     * 版式：标题用字体卡的宋体系，正文用黑体系；分组以细线分隔而不加卡片框，
     * 层级靠字重、字号与留白表达。
     */
    const STYLES = {
      page: {
        maxWidth: 680,
        margin: '0 auto',
        padding: '40px 24px 64px',
        display: 'flex',
        flexDirection: 'column',
        gap: 24,
        fontFamily: type.family.ui,
        fontSize: type.size.body,
        lineHeight: type.leading.body,
        color: color.ink,
      },
      head: { display: 'flex', flexDirection: 'column', gap: 6 },
      title: {
        margin: 0,
        fontFamily: type.family.display,
        fontSize: type.size.display,
        lineHeight: type.leading.display,
        fontWeight: type.weight.semibold,
      },
      lede: { margin: 0, fontSize: type.size.body, color: color.inkMuted },
      composer: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        padding: '14px 16px 12px',
        borderRadius: 10,
        background: color.raised,
        border: `1px solid ${color.rule}`,
      },
      input: {
        resize: 'vertical',
        minHeight: 56,
        padding: 0,
        fontSize: type.size.lead,
        lineHeight: type.leading.body,
        border: 0,
        outline: 'none',
        background: 'transparent',
        color: 'inherit',
        fontFamily: 'inherit',
      },
      composerBar: { display: 'flex', justifyContent: 'flex-end' },
      primaryButton: {
        padding: '7px 18px',
        fontSize: type.size.body,
        fontFamily: 'inherit',
        borderRadius: 7,
        border: 0,
        cursor: 'pointer',
        background: color.brand,
        color: color.onBrand,
      },
      ghostButton: {
        padding: '3px 8px',
        fontSize: type.size.caption,
        fontFamily: 'inherit',
        borderRadius: 6,
        border: 0,
        background: 'transparent',
        color: color.inkMuted,
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      },
      dangerButton: {
        padding: '3px 8px',
        fontSize: type.size.caption,
        fontFamily: 'inherit',
        borderRadius: 6,
        border: `1px solid ${color.danger}`,
        background: 'transparent',
        color: color.danger,
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      },
      retryBox: { display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-start' },
      notice: { margin: 0, fontSize: type.size.body, color: color.inkMuted },
      muted: { margin: 0, fontSize: type.size.body, color: color.inkMuted },
      groups: { display: 'flex', flexDirection: 'column', gap: 32 },
      group: { display: 'flex', flexDirection: 'column' },
      groupHead: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 10,
        paddingBottom: 8,
        borderBottom: `1px solid ${color.ruleStrong}`,
      },
      groupName: {
        margin: 0,
        fontFamily: type.family.display,
        fontSize: type.size.title,
        fontWeight: type.weight.semibold,
        lineHeight: type.leading.display,
      },
      count: { fontSize: type.size.caption, color: color.inkMuted, marginRight: 'auto' },
      list: { listStyle: 'none', margin: 0, padding: 0 },
      item: { padding: '12px 0', borderBottom: `1px solid ${color.rule}` },
      itemText: {
        margin: 0,
        fontSize: type.size.lead,
        lineHeight: type.leading.body,
        whiteSpace: 'pre-wrap',
      },
      itemTextModified: {
        margin: 0,
        fontSize: type.size.lead,
        lineHeight: type.leading.body,
        whiteSpace: 'pre-wrap',
        textDecorationLine: 'line-through',
        textDecorationThickness: 'from-font',
        color: color.inkMuted,
      },
      itemMeta: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 4,
        justifyContent: 'space-between',
      },
      meta: { fontSize: type.size.caption, color: color.inkMuted },
      card: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        padding: '16px 18px 14px',
        borderRadius: 10,
        background: color.raised,
        border: `1px solid ${color.rule}`,
      },
      cardTitle: {
        margin: 0,
        fontFamily: type.family.display,
        fontSize: type.size.title,
        fontWeight: type.weight.semibold,
      },
      recentList: {
        listStyle: 'none',
        margin: 0,
        padding: 0,
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
      },
      recentItem: { fontSize: type.size.body, lineHeight: type.leading.body },
      cardLink: {
        alignSelf: 'flex-start',
        padding: 0,
        border: 0,
        background: 'transparent',
        color: color.brand,
        fontFamily: 'inherit',
        fontSize: type.size.body,
        cursor: 'pointer',
      },
    }

    /** 焦点与禁用态：inline style 没有 :focus-visible，由页面级样式表补上。 */
    const CSS = [
      `.${CLASS_PAGE} button:focus-visible, .${CLASS_PAGE} textarea:focus-visible {`,
      `  outline: 2px solid ${color.brand};`,
      '  outline-offset: 2px;',
      '}',
      `.${CLASS_PAGE} button:disabled { opacity: 0.5; cursor: default; }`,
      `.${CLASS_PAGE} .edu-memory-composer:focus-within { border-color: ${color.ruleStrong}; }`,
    ].join('\n')

    /** 必需的服务：槽位与远端投影（$mount 用的根投影）。 */
    const inject = ['slots', 'remote']

    function apply(ctx) {
      ctx.effect(() => {
        const tag = document.createElement('style')
        tag.setAttribute('data-edu-memory', '')
        tag.textContent = CSS
        document.head.appendChild(tag)
        return () => tag.remove()
      }, 'edu-memory: 焦点与禁用样式')
      const mounted = (async () => {
        const disposer = await ctx.remote.$mount({ package: PKG, descriptors: DESCRIPTORS })
        ctx.effect(() => disposer)
      })()
      const MemoryPage = makeMemoryPage(ctx, mounted)
      ctx.slots.inject('main', () =>
        ctx.slots.register({ name: 'main', key: SLOT_KEY }, MemoryPage),
      )
      ctx.slots.inject('home.card', () =>
        ctx.slots.register(
          { name: 'home.card', id: SLOT_KEY, order: 10 },
          makeMemoryCard(ctx, mounted),
        ),
      )
      ctx.slots.inject('sidebar.panellist', () =>
        ctx.slots.register(
          {
            name: 'sidebar.panellist',
            id: SLOT_KEY,
            order: 20,
            label: () => TEXT.pageShort,
          },
          MemoryIcon,
        ),
      )
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
